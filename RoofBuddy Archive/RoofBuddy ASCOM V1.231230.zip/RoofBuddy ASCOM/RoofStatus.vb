﻿Public Class frmRoofStatus
    Private Sub btnAbort_Click(sender As Object, e As EventArgs) Handles btnAbort.Click
        Dome.abortBtn = True
    End Sub
End Class