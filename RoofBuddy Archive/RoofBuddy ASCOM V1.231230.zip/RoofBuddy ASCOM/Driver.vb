'tabs=4

' This definition is used to select code that's only applicable for one device type
#Const Device = "Dome"
#Disable Warning BC42017 ' Late bound resolution
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports System.Globalization
Imports System.Runtime.InteropServices
Imports System.Text
Imports ASCOM
Imports ASCOM.Astrometry
Imports ASCOM.Astrometry.AstroUtils
Imports ASCOM.DeviceInterface
Imports ASCOM.Utilities
Imports System.IO.Ports
Imports System.Timers

'bf00c596-fd48-479d-af92-fee856255001

'Use "2C6..." for Any CPU
'Use "719..." for x64
'<Guid("71953E82-CB79-4E80-A129-AFAAB993AF04")>
'<Guid("2C6B8C60-D79D-460C-B964-BF47B07DA342")>
<Guid("AB8BBEE5-77C9-43FB-845A-A45B7C1F7A16")>
<ClassInterface(ClassInterfaceType.None)>
Public Class Dome
    Implements IDomeV2
    'Friend Shared version As String = "V1.231009.x64"
    Friend Shared version As String = "V1.231230"
#Region "Variables, Objects and Constants"
    ' Driver ID and descriptive string that shows in the Chooser
    Friend Shared driverID As String = "ASCOM.RoofBuddy.Dome"
    Friend Shared driverDescription As String = "RoofBuddy"

    Friend Shared comPortProfileName As String = "COM Port" 'Constants used for Profile persistence
    Friend Shared showStatusFormProfileName As String = "Show move progress"
    Friend Shared traceStateProfileName As String = "Trace Level"
    Friend Shared canSpeakProfileName As String = "Can speak"

    Friend Shared comPortDefault As String = "COM14"
    Friend Shared showStatusFormDefault As String = "False"
    Friend Shared traceStateDefault As String = "False"
    Friend Shared canSpeakDefault As String = "True"

    Friend Shared comPort As String ' Variables to hold the current device configuration
    Friend Shared showStatusForm As Boolean
    Friend Shared traceState As Boolean
    Friend Shared canSpeak As Boolean

    Private connectedState As Boolean ' Private variable to hold the connected state
    Private utilities As Util ' Private variable to hold an ASCOM Utilities object
    Private astroUtilities As AstroUtils ' Private variable to hold an AstroUtils object to provide the Range method
    Private TL As TraceLogger ' Private variable to hold the trace logger object (creates a diagnostic log file with information that you specify)
    Friend Shared roofAction As String = "h"
    Friend Shared roofStatusText As String = ""
    Friend Shared roofStatus As ShutterState = ShutterState.shutterError
    Friend Shared moveStatus As ShutterState = ShutterState.shutterError
    Friend Shared moveOK As Boolean = True
    Friend Shared roofMovePeriod As String = "50"
    Friend Shared roofMoving As Boolean = False
    Friend Shared roofMoveProg As Integer = 0
    Friend Shared battery As String
    Friend Shared abortBtn As Boolean
    Friend Shared sustain As Integer = 0
    Friend Shared TmrMain As Timers.Timer
    Friend Shared TmrTimer As Timers.Timer
    Friend Shared TmrSpeak As Timers.Timer
    Friend Shared InISR As Boolean
    Friend Shared ISRenabled As Boolean
    Friend Shared ISRcmd As String
    Friend Shared Resp As String
    Friend Shared Switches As String
    Friend Shared spkSentence As String
    Friend Shared canTalk As Boolean = True
    Friend Shared StatusBox As New frmRoofStatus()

    Friend Shared serialBusy As Boolean = False
    'Private frmRBstatus As New RBStatusForm()

#End Region
    ' Constructor - Must be public for COM registration!
    Public Sub New()

        ReadProfile() ' Read device configuration from the ASCOM Profile store
        TL = New TraceLogger("", "RoofBuddy")
        TL.Enabled = traceState
        TL.LogMessage("Dome", "Starting initialisation")

        connectedState = False ' Initialise connected to false
        utilities = New Util() ' Initialise util object
        astroUtilities = New AstroUtils 'Initialise new astro utilities object

        InISR = False
        ISRenabled = False
        TmrMain = New Timers.Timer(1)
        AddHandler TmrMain.Elapsed, New ElapsedEventHandler(AddressOf TimerMain)
        TmrMain.Stop()

        TmrTimer = New Timers.Timer(1000)
        AddHandler TmrTimer.Elapsed, New ElapsedEventHandler(AddressOf TimerTimer)
        TmrTimer.Stop()

        TmrSpeak = New Timers.Timer(1)
        AddHandler TmrSpeak.Elapsed, New ElapsedEventHandler(AddressOf TimerSpeak)
        TmrSpeak.Stop()

        TL.LogMessage("Dome", "Completed initialisation")
    End Sub

    '
    ' PUBLIC COM INTERFACE IDomeV2 IMPLEMENTATION
    '

#Region "Common properties and methods"
    ''' <summary>
    ''' Displays the Setup Dialog form.
    ''' If the user clicks the OK button to dismiss the form, then
    ''' the new settings are saved, otherwise the old values are reloaded.
    ''' THIS IS THE ONLY PLACE WHERE SHOWING USER INTERFACE IS ALLOWED!
    ''' </summary>
    Public Sub SetupDialog() Implements IDomeV2.SetupDialog
        ' consider only showing the setup dialog if not connected
        ' or call a different dialog if connected
        ' If IsConnected Then
        ' System.Windows.Forms.MessageBox.Show("Already connected, just press OK")
        ' End If

        Using F As New SetupDialogForm()
            Dim result As System.Windows.Forms.DialogResult = F.ShowDialog()
            If result = DialogResult.OK Then
                WriteProfile() ' Persist device configuration values to the ASCOM Profile store
            End If
        End Using
    End Sub

    Public ReadOnly Property SupportedActions() As ArrayList Implements IDomeV2.SupportedActions
        Get
            TL.LogMessage("SupportedActions Get", "Returning empty arraylist")
            Return New ArrayList()
        End Get
    End Property

    Public Function Action(ByVal ActionName As String, ByVal ActionParameters As String) As String Implements IDomeV2.Action
        Throw New ActionNotImplementedException("Action " & ActionName & " is not supported by this driver")
    End Function

    Public Sub CommandBlind(ByVal Command As String, Optional ByVal Raw As Boolean = False) Implements IDomeV2.CommandBlind
        CheckConnected("CommandBlind")
        ' TODO The optional CommandBlind method should either be implemented OR throw a MethodNotImplementedException
        ' If implemented, CommandBlind must send the supplied command to the mount And return immediately without waiting for a response

        Throw New MethodNotImplementedException("CommandBlind")
    End Sub

    Public Function CommandBool(ByVal Command As String, Optional ByVal Raw As Boolean = False) As Boolean _
        Implements IDomeV2.CommandBool
        CheckConnected("CommandBool")
        ' TODO The optional CommandBool method should either be implemented OR throw a MethodNotImplementedException
        ' If implemented, CommandBool must send the supplied command to the mount, wait for a response and parse this to return a True Or False value

        ' Dim retString as String = CommandString(command, raw) ' Send the command And wait for the response
        ' Dim retBool as Boolean = XXXXXXXXXXXXX ' Parse the returned string And create a boolean True / False value
        ' Return retBool ' Return the boolean value to the client

        Throw New MethodNotImplementedException("CommandBool")
    End Function

    Public Function CommandString(ByVal Command As String, Optional ByVal Raw As Boolean = False) As String _
        Implements IDomeV2.CommandString
        CheckConnected("CommandString")
        ' TODO The optional CommandString method should either be implemented OR throw a MethodNotImplementedException
        ' If implemented, CommandString must send the supplied command to the mount and wait for a response before returning this to the client

        Throw New MethodNotImplementedException("CommandString")
    End Function

    Public Property Connected() As Boolean Implements IDomeV2.Connected
        Get
            TL.LogMessage("Connected Get", IsConnected.ToString())
            Return IsConnected
        End Get
        Set(value As Boolean)
            TL.LogMessage("Connected Set", value.ToString() + " " + version)
            If value = IsConnected Then
                Return
            End If

            If value Then
                WaitForISR()                        ' Turn off timer interrupts
                ISRenabled = False
                InISR = False
                TmrMain.Stop()
                connectedState = True
                If SerialCmd("h") <> "h" Then   '    Roof responding?
                    value = connectedState
                    TL.LogMessage("Connected Set", "No response on port " + comPort + " - version " + version)
                Else
                    TL.LogMessage("Connected Set", "Connected to port " + comPort)
                    TmrMain.Interval = 1
                    ISRcmd = ""
                    ISRenabled = True
                    spkSentence = "Move aborted"
                    roofStatusText = ""
                    canTalk = False
                    moveOK = True
                    TmrMain.Start()
                    WaitForISR()
                    TL.LogMessage("Connected Set", "GetRoofStatus - " + roofStatusText)
                    If showStatusForm Then
                        StatusBox = New frmRoofStatus()
                        StatusBox.Visible = False
                        StatusBox.Show()
                        StatusBox.Visible = False
                    End If
                End If
            End If
            If Not value Then
                ' TODO disconnect from the device
                SerialCmd("H")
                connectedState = False
                TmrMain.Stop()
                TmrSpeak.Stop()
                TmrTimer.Stop()
                StatusBox.Visible = False
                StatusBox.Close()
                StatusBox.Dispose()
                TL.LogMessage("Connected Set", "Disconnected from port " + comPort)
            End If
        End Set
    End Property

    Public ReadOnly Property Description As String Implements IDomeV2.Description
        Get
            ' this pattern seems to be needed to allow a public property to return a private field
            Dim d As String = driverDescription
            TL.LogMessage("Description Get", d)
            Return d
        End Get
    End Property

    Public ReadOnly Property DriverInfo As String Implements IDomeV2.DriverInfo
        Get
            'Dim m_version As Version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version
            ' TODO customise this driver description
            Dim s_driverInfo As String = "For RoofBuddy roof controller. Version: " + version
            TL.LogMessage("DriverInfo Get", s_driverInfo)
            Return s_driverInfo
        End Get
    End Property

    Public ReadOnly Property DriverVersion() As String Implements IDomeV2.DriverVersion
        Get
            ' Get our own assembly and report its version number
            TL.LogMessage("DriverVersion Get", Reflection.Assembly.GetExecutingAssembly.GetName.Version.ToString(2))
            'TL.LogMessage("DriverVersion Get", version)
            Return Reflection.Assembly.GetExecutingAssembly.GetName.Version.ToString(2)
        End Get
    End Property

    Public ReadOnly Property InterfaceVersion() As Short Implements IDomeV2.InterfaceVersion
        Get
            TL.LogMessage("InterfaceVersion Get", "2")
            Return 2
        End Get
    End Property

    Public ReadOnly Property Name As String Implements IDomeV2.Name
        Get
            Dim s_name As String = "RoofBuddy"
            TL.LogMessage("Name Get", s_name)
            Return s_name
        End Get
    End Property

    Public Sub Dispose() Implements IDomeV2.Dispose
        ' Clean up the trace logger and util objects
        TL.Enabled = False
        TL.Dispose()
        TL = Nothing
        utilities.Dispose()
        utilities = Nothing
        astroUtilities.Dispose()
        astroUtilities = Nothing
    End Sub

#End Region

#Region "IDome Implementation"

    Public Sub AbortSlew() Implements IDomeV2.AbortSlew
        TL.LogMessage("AbortSlew", "Operation aborted")
        CheckConnected("AbortSlew")
        SerialCmd("H")
        'If roofStatus = ShutterState.shutterClosed Or roofStatus = ShutterState.shutterOpen Then Exit Sub
        roofStatus = ShutterState.shutterError
        Exit Sub

        'roofAction = "h"
        'If Not StatusBox.Visible Then Exit Sub
        'roofStatusText = "Move aborted"
        'StatusBox.lblRoofState.Text = roofStatusText
        'Application.DoEvents()
    End Sub

    Public ReadOnly Property Altitude() As Double Implements IDomeV2.Altitude
        Get
            TL.LogMessage("Altitude Get", "Not implemented")
            Throw New ASCOM.PropertyNotImplementedException("Altitude", False)
        End Get
    End Property

    Public ReadOnly Property AtHome() As Boolean Implements IDomeV2.AtHome
        Get
            TL.LogMessage("AtHome", "Not implemented")
            Throw New ASCOM.PropertyNotImplementedException("AtHome", False)
        End Get
    End Property

    Public ReadOnly Property AtPark() As Boolean Implements IDomeV2.AtPark
        Get
            TL.LogMessage("AtPark", "Not implemented")
            Throw New ASCOM.PropertyNotImplementedException("AtPark", False)
        End Get
    End Property

    Public ReadOnly Property Azimuth() As Double Implements IDomeV2.Azimuth
        Get
            TL.LogMessage("Azimuth", "Not implemented")
            Throw New ASCOM.PropertyNotImplementedException("Azimuth", False)
        End Get
    End Property

    Public ReadOnly Property CanFindHome() As Boolean Implements IDomeV2.CanFindHome
        Get
            TL.LogMessage("CanFindHome Get", False.ToString())
            Return False
        End Get
    End Property

    Public ReadOnly Property CanPark() As Boolean Implements IDomeV2.CanPark
        Get
            TL.LogMessage("CanPark Get", False.ToString())
            Return False
        End Get
    End Property

    Public ReadOnly Property CanSetAltitude() As Boolean Implements IDomeV2.CanSetAltitude
        Get
            TL.LogMessage("CanSetAltitude Get", False.ToString())
            Return False
        End Get
    End Property

    Public ReadOnly Property CanSetAzimuth() As Boolean Implements IDomeV2.CanSetAzimuth
        Get
            TL.LogMessage("CanSetAzimuth Get", False.ToString())
            Return False
        End Get
    End Property

    Public ReadOnly Property CanSetPark() As Boolean Implements IDomeV2.CanSetPark
        Get
            TL.LogMessage("CanSetPark Get", False.ToString())
            Return False
        End Get
    End Property

    Public ReadOnly Property CanSetShutter() As Boolean Implements IDomeV2.CanSetShutter
        Get
            TL.LogMessage("CanSetShutter Get", True.ToString())
            Return True
        End Get
    End Property

    Public ReadOnly Property CanSlave() As Boolean Implements IDomeV2.CanSlave
        Get
            TL.LogMessage("CanSlave Get", False.ToString())
            Return False
        End Get
    End Property

    Public ReadOnly Property CanSyncAzimuth() As Boolean Implements IDomeV2.CanSyncAzimuth
        Get
            TL.LogMessage("CanSyncAzimuth Get", False.ToString())
            Return False
        End Get
    End Property

    Public Sub CloseShutter() Implements IDomeV2.CloseShutter
        TL.LogMessage("CloseShutter", "Close roof")
        CheckConnected("CloseShutter")
        WaitForISR()                                              ' Wait for the latest status from the controller

        If roofAction = "C" Then
            TL.LogMessage("CloseShutter", "Already closed")
            Exit Sub
        End If
        If roofAction = "o" Then
            TL.LogMessage("CloseShutter", "Unable to close roof - roof is opening")
            Exit Sub
        End If
        If roofAction = "c" Then
            TL.LogMessage("CloseShutter", "Already closing")
            Exit Sub
        End If

        TL.LogMessage("CloseShutter", "Trying to close")
        For n = 1 To 5                                          ' Wait up to 5 seconds to ensure both switches are open
            ISRcmd = "C"
            WaitForISR()
            If Switches <> "M" Then Exit For
        Next
        If Resp = "E" Then
            moveOK = False
            roofStatus = ShutterState.shutterError
            TL.LogMessage("CloseShutter", "Error - connection lost?")
            Exit Sub
        End If
        If roofAction = "c" Then TL.LogMessage("CloseShutter", "Roof is closing")
        If roofAction = "C" Then TL.LogMessage("CloseShutter", "Roof closed")
    End Sub

    Public Sub FindHome() Implements IDomeV2.FindHome
        TL.LogMessage("FindHome", "Not implemented")
        Throw New ASCOM.MethodNotImplementedException("FindHome")
    End Sub

    Public Sub OpenShutter() Implements IDomeV2.OpenShutter
        TL.LogMessage("OpenShutter", "Open roof")
        CheckConnected("OpenShutter")
        WaitForISR()                                              ' Wait for the latest status from the controller

        If roofAction = "O" Then
            TL.LogMessage("OpenShutter", "Already open")
            Exit Sub
        End If
        If roofAction = "c" Then
            TL.LogMessage("OpenShutter", "Unable to open roof - roof is closing")
            Exit Sub
        End If
        If roofAction = "o" Then
            TL.LogMessage("OpenShutter", "Already opening")
            Exit Sub
        End If

        TL.LogMessage("OpenShutter", "Trying to open")
        For n = 1 To 5                                          ' Wait up to 5 seconds to ensure both switches are open
            ISRcmd = "O"
            WaitForISR()
            If Switches <> "M" Then Exit For
        Next
        If Resp = "E" Then
            moveOK = False
            roofStatus = ShutterState.shutterError
            TL.LogMessage("OpenShutter", "Error - connection lost?")
            Exit Sub
        End If
        If roofAction = "o" Then TL.LogMessage("OpenShutter", "Roof is opening")
        If roofAction = "O" Then TL.LogMessage("OpenShutter", "Roof open")
    End Sub

    Public Sub Park() Implements IDomeV2.Park
        TL.LogMessage("Park", "Not implemented")
        Throw New ASCOM.MethodNotImplementedException("Park")
    End Sub

    Public Sub SetPark() Implements IDomeV2.SetPark
        TL.LogMessage("SetPark", "Not implemented")
        Throw New ASCOM.MethodNotImplementedException("SetPark")
    End Sub

    Public ReadOnly Property ShutterStatus() As ShutterState Implements IDomeV2.ShutterStatus
        Get
            CheckConnected("ShutterStatus")
            TL.LogMessage("ShutterStatus", roofStatus.ToString())
            Return roofStatus
        End Get
    End Property

    Public Property Slaved() As Boolean Implements IDomeV2.Slaved
        Get
            TL.LogMessage("Slaved Get", False.ToString())
            Return False
        End Get
        Set(value As Boolean)
            TL.LogMessage("Slaved Set", "not implemented")
            Throw New ASCOM.PropertyNotImplementedException("Slaved", True)
        End Set
    End Property

    Public Sub SlewToAltitude(Altitude As Double) Implements IDomeV2.SlewToAltitude
        TL.LogMessage("SlewToAltitude", "Not implemented")
        Throw New ASCOM.MethodNotImplementedException("SlewToAltitude")
    End Sub

    Public Sub SlewToAzimuth(Azimuth As Double) Implements IDomeV2.SlewToAzimuth
        TL.LogMessage("SlewToAzimuth", "Not implemented")
        Throw New ASCOM.MethodNotImplementedException("SlewToAzimuth")
    End Sub

    Public ReadOnly Property Slewing() As Boolean Implements IDomeV2.Slewing
        Get
            TL.LogMessage("Slewing Get", False.ToString())
            Return False
        End Get
    End Property

    Public Sub SyncToAzimuth(Azimuth As Double) Implements IDomeV2.SyncToAzimuth
        TL.LogMessage("SyncToAzimuth", "Not implemented")
        Throw New ASCOM.MethodNotImplementedException("SyncToAzimuth")
    End Sub

#End Region

#Region "Private properties and methods"
    ' here are some useful properties and methods that can be used as required
    ' to help with

#Region "ASCOM Registration"

    Private Shared Sub RegUnregASCOM(ByVal bRegister As Boolean)

        Using P As New Profile() With {.DeviceType = "Dome"}
            If bRegister Then
                P.Register(driverID, driverDescription)
            Else
                P.Unregister(driverID)
            End If
        End Using

    End Sub

    <ComRegisterFunction()>
    Public Shared Sub RegisterASCOM(ByVal T As Type)

        RegUnregASCOM(True)

    End Sub

    <ComUnregisterFunction()>
    Public Shared Sub UnregisterASCOM(ByVal T As Type)

        RegUnregASCOM(False)

    End Sub

#End Region

    ''' <summary>
    ''' Returns true if there is a valid connection to the driver hardware
    ''' </summary>
    Private ReadOnly Property IsConnected As Boolean
        Get
            ' TODO check that the driver hardware connection exists and is connected to the hardware
            Return connectedState
        End Get
    End Property

    ''' <summary>
    ''' Use this function to throw an exception if we aren't connected to the hardware
    ''' </summary>
    ''' <param name="message"></param>
    Private Sub CheckConnected(ByVal message As String)
        If Not IsConnected Then
            Throw New NotConnectedException(message)
        End If
    End Sub

    ''' <summary>
    ''' Read the device configuration from the ASCOM Profile store
    ''' </summary>
    Friend Sub ReadProfile()
        Using driverProfile As New Profile()
            driverProfile.DeviceType = "Dome"
            traceState = CBool(driverProfile.GetValue(driverID, traceStateProfileName, String.Empty, traceStateDefault))
            comPort = driverProfile.GetValue(driverID, comPortProfileName, String.Empty, comPortDefault)
            showStatusForm = CBool(driverProfile.GetValue(driverID, showStatusFormProfileName, String.Empty, showStatusFormDefault))
            canSpeak = CBool(driverProfile.GetValue(driverID, canSpeakProfileName, String.Empty, canSpeakDefault))
        End Using
    End Sub

    ''' <summary>
    ''' Write the device configuration to the  ASCOM  Profile store
    ''' </summary>
    Friend Sub WriteProfile()
        Using driverProfile As New Profile()
            driverProfile.DeviceType = "Dome"
            driverProfile.WriteValue(driverID, "Version", version)
            driverProfile.WriteValue(driverID, traceStateProfileName, traceState.ToString)
            driverProfile.WriteValue(driverID, comPortProfileName, comPort.ToString)
            driverProfile.WriteValue(driverID, showStatusFormProfileName, showStatusForm.ToString)
            driverProfile.WriteValue(driverID, canSpeakProfileName, canSpeak.ToString)
        End Using

    End Sub

#End Region
#Region "My Stuff"
    Function SerialCmd(cmd As String) As String
        ' Note that 'cmd' is sent as its ASCII code
        If Not connectedState Then Return "Error - No connection"
        Dim cmdStr As String = cmd
        Dim retStr As String = ""
        Dim objSerial As New SerialPort

        TmrTimer.Stop()                         ' Wait for upto 2 seconds until SerialCmd is free
        TmrTimer.Interval = 2000
        TmrTimer.Start()
        While TmrTimer.Enabled
            If Not serialBusy Then Exit While
        End While
        serialBusy = True
        If Not connectedState Then Return "Error - No connection"

        If cmdStr <> "" Then cmdStr = "^" + Asc(cmdStr).ToString + "$" ' "^" is the escape character and  "$" is the terminator
        With objSerial
            .PortName = Dome.comPort
            .BaudRate = 9600
            .ReadTimeout = 3000
            .WriteTimeout = 1000
        End With

        TmrTimer.Stop()                                 ' Spend upto 5 secs trying to open COM port
        TmrTimer.Interval = 5000
        TmrTimer.Start()
        While TmrTimer.Enabled
            Try
                objSerial.Open()
                'objSerial.DiscardInBuffer()
                'objSerial.DiscardOutBuffer()
                retStr = ""
                Exit While
            Catch ex As Exception
                retStr = "Error - Lost connection"
            End Try
        End While

        If retStr = "" Then                                     ' Send command
            Try
                objSerial.Write(cmdStr)
                retStr = objSerial.ReadTo("$")     ' Get response if required
                TL.LogMessage("[SerialCommand]", "  [Sent: " + cmdStr + " (" + cmd + ") Got: " + retStr + "]")
            Catch ex As Exception
                retStr = "Error - No response"
            End Try
        End If

        objSerial.Close()
        objSerial.Dispose()
        serialBusy = False
        If retStr.Length > 10 Then
            connectedState = False
            TL.LogMessage("[SerialCommand]", "  [" + retStr + " when trying to send " + cmd + ", connectedState = False]")
        End If
        Return retStr
    End Function

    Sub WaitForISR()
        TL.LogMessage("WaitForISR", "ISRenable: " + ISRenabled.ToString)
        If Not ISRenabled Then Exit Sub
        TL.LogMessage("WaitForISR", "Waiting for next ISR event...")
        Do While Not InISR
        Loop
        TL.LogMessage("WaitForISR", "Waiting for ISR to finish...")
        Do While InISR
        Loop
        TL.LogMessage("WaitForISR", "ISR finished")
    End Sub

    Private Sub TimerTimer(sender As Object, e As ElapsedEventArgs)
        TmrTimer.Stop()
    End Sub

    Private Sub TimerMain(sender As Object, e As ElapsedEventArgs)
        TL.LogMessage("[TimerMain]", "  [IN - Cmd: " + ISRcmd + "]")
        TmrMain.Stop()
        TmrMain.Interval = 1000
        If Not ISRenabled Then
            InISR = False
            Exit Sub
        End If
        InISR = True
        Resp = ""

        If abortBtn Then
            abortBtn = False
            SerialCmd("H")
        End If

        If Not connectedState Then GoTo LostConnection

        If ISRcmd <> "" Then
            For n = 1 To 5
                connectedState = True
                Resp = SerialCmd(ISRcmd)
                If Left(Resp, 1) <> "E" Then Exit For
            Next
            If Not connectedState Then GoTo LostConnection

            If ISRcmd = "O" Then
                If Resp = "r" Or Resp = "b" Or Left(Resp, 1) = "E" Then ' Raining, inadequate power or connection error?
                    roofStatus = ShutterState.shutterError
                    roofMoving = False
                    roofAction = "h"
                    TL.LogMessage("[TimerMain]", "  [" + Resp + " => shutterError]")
                    moveOK = False
                Else
                    roofMoving = True
                    roofAction = "o"
                    moveOK = True
                End If
                canSpeak = True
            End If
            If ISRcmd = "C" Then
                If Resp = "B" Or Left(Resp, 1) = "E " Then              ' Inadequate power or connection error?
                    roofStatus = ShutterState.shutterError
                    roofMoving = False
                    roofAction = "h"
                    TL.LogMessage("[TimerMain]", "  [" + Resp + " => shutterError]")
                    moveOK = False
                Else
                    roofMoving = True
                    roofAction = "c"
                    moveOK = True
                End If
                canSpeak = True
            End If
            If ISRcmd = "H" Then
                roofMoving = True
                roofAction = "h"
                canSpeak = True
            End If
        Else
            Switches = SerialCmd("w")

            If showStatusForm Then
                If roofMoving Then
                    If Not StatusBox.Visible Then
                        StatusBox.prgBar.Value = 0
                        roofStatusText = ""
                        StatusBox.lblRoofState.Text = ""
                        StatusBox.Visible = True
                    End If
                    StatusBox.lblTick.Text = IIf(StatusBox.lblTick.Text = "/", "\", "/").ToString
                    roofStatusText = "Lost connection"                    ' Start off assuming connection is lost

                    resp = SerialCmd("b")
                    If Not connectedState Then GoTo LostConnection
                    battery = resp
                    StatusBox.lblBattery.Text = battery + IIf(battery.Length > 4, "", "V").ToString

                    resp = SerialCmd("g")
                    If Not connectedState Then GoTo LostConnection
                    roofMoveProg = CInt(resp)

                    If roofAction = "c" Then roofMoveProg = 100 - roofMoveProg
                    If roofAction = "C" Then roofMoveProg = 0
                    If roofAction = "h" Then roofMoveProg = 0
                    StatusBox.prgBar.Value = roofMoveProg
                    Application.DoEvents()
                Else
                    If sustain <= 0 Then
                        StatusBox.Visible = False
                    Else
                        sustain -= 1
                    End If
                End If
            End If

            If moveOK Then
                Resp = SerialCmd("s")
                If Not connectedState Then GoTo LostConnection
                Select Case Left(Resp, 1)
                    Case "C"
                        roofStatusText = "Roof closed"
                        roofStatus = ShutterState.shutterClosed
                        roofMoving = False
                        roofAction = "C"
                    Case "c"
                        roofStatusText = "Closing roof"
                        roofStatus = ShutterState.shutterClosing
                        roofMoving = True
                        roofAction = "c"
                    Case "O"
                        roofStatusText = "Roof open"
                        roofStatus = ShutterState.shutterOpen
                        roofMoving = False
                        roofAction = "O"
                    Case "o"
                        roofStatusText = "Opening roof"
                        roofStatus = ShutterState.shutterOpening
                        roofMoving = True
                        roofAction = "o"
                    Case "h"
                        roofStatusText = "Move aborted"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "H"
                        roofStatusText = "Move aborted"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "p"
                        roofStatusText = "Parking telescope"
                        roofStatus = ShutterState.shutterOpening
                        roofMoving = False
                        roofAction = "o"
                    Case "P"
                        roofStatusText = "Parking telescope"
                        roofStatus = ShutterState.shutterClosing
                        roofMoving = False
                        roofAction = "c"
                    Case "b"
                        roofStatusText = "Inadequate power"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "B"
                        roofStatusText = "Inadequate power"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "t"
                        roofStatusText = "Move timed out"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "T"
                        roofStatusText = "Move timed out"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "r"
                        roofStatusText = "Rain detected"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "R"
                        roofStatusText = "Rain detected"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "s"
                        roofStatusText = "Telescope not safe"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "S"
                        roofStatusText = "Telescope not safe"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "l"
                        roofStatusText = "Telescope not responding"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "L"
                        roofStatusText = "Telescope not responding"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "Error - No connection"
                        roofStatusText = "No connection"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "Error - No response"
                        roofStatusText = "No response"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case "Error - Lost connection"
                        roofStatusText = "Lost connection"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                    Case Else
                        roofStatusText = "Unknown error"
                        roofStatus = ShutterState.shutterError
                        roofMoving = False
                        roofAction = "h"
                End Select
            End If
        End If

LostConnection:
        'If roofMoving AndAlso StatusBox.Visible Then
        If StatusBox.lblRoofState.Text <> roofStatusText Then
            StatusBox.lblRoofState.Text = roofStatusText
            sustain = 2
            Speak(roofStatusText)
            canSpeak = True
        End If
        If StatusBox.Visible Then Application.DoEvents()
        If Not connectedState Then
            roofStatus = ShutterState.shutterError
            roofMoving = False
            roofAction = "h"
        End If
        If Not connectedState Then
            TmrMain.Stop()
            ISRenabled = False
        Else
            TmrMain.Start()
        End If
        TL.LogMessage("[TimerMain]", "  [OUT]")
        ISRcmd = ""
        InISR = False
    End Sub

    Sub Speak(sentence As String)
        TL.LogMessage("Speak", "Sentence: " + sentence)
        If spkSentence = sentence Then Exit Sub
        spkSentence = sentence
        TmrSpeak.Interval = 1
        TmrSpeak.Enabled = True
        TmrSpeak.Start()
    End Sub

    Private Sub TimerSpeak(sender As Object, e As ElapsedEventArgs)
        TmrSpeak.Stop()
        TL.LogMessage("TimerSpeak", "Speaking: " + spkSentence)
        If canTalk = canTalk Then
            Dim SAPI As Object
            SAPI = CreateObject("SAPI.spvoice")
            SAPI.Voice = SAPI.GetVoices.Item(0)
            SAPI.rate = 0
            SAPI.speak(spkSentence)
        End If
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

#End Region

#Region "RoofBuddy commands"
    ' e     Returns 'e' meaning RoofBuddy is responding. Also, turn on the rain sensor
    ' O     Open roof completely
    ' o     TopBox open button has been pressed to open roof
    ' C     Close roof completely
    ' c     TopBox open button has been pressed to close roof
    ' s     Get roof status: 'C' = Closed, 'c' = closing, 'O' = Opened, 'o' = Opening, 'H' = Stopped, etc
    ' b     Returns battery voltage. >= 12.5V = OK, < 12.5V = Charge battery
    ' R     Restart Rain Sensor
    ' r     Returns: 1 = wet, 0 = dry
    ' I     Pretend it's raining
    ' i     Pretend it's dry
    ' M     Set max time to move roof: 0 to 255 seconds
    ' m     Get roof mover timer value
    ' X     Set maximum motor speed
    ' x     Get maximum motor speed
    ' g     Get estimated time to go to move roof as a percentage
    ' U     Set parameters 'P'/'p' Park, 'I'/'i' is parked, 'A'/'a' accelerometer, 'B'/'b' battery (UPPER = on, LOWER = off)
    ' u     Get 'P' Park, 'I' is parked, 'A' accelerometer, 'B' battery
    ' H     Stop motor immediately
    ' h     Bring motor to a slow stop
    ' D     Store and use this declination for parking to EEPROM
    ' d     Get stored declination for parking
    ' A     Store and use this hour angle for parking to EEPROM
    ' a     Get stored hour angle for parking
    ' L     Get last command response
    ' l     Is telescope connected and responding? '1' = yes, '0' = no
    ' _     Instruct LX200 to slew to home position
    ' p     Is LX200 parked? '1' = yes, '0' = no
    ' Q     Stop parking the telescope
    ' V     Send version
    ' v     Send this sketch's variables
    ' T     Telescope is safely positioned to move roof
    ' t     Telescope is not safely positioned to move roof
    ' ~     Show Arduino's pin statuses
    ' :     Send a command directly to the LX200 and send back any response
    ' Z     Test mode commands
    ' F     Re-format EEPROM
    ' S     Return what RB thinks is the scope safety
    ' /     Restart RoofBuddy controller's Arduino
#End Region
End Class