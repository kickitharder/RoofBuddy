Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports ASCOM.RoofBuddy
Imports ASCOM.Utilities
Imports System.IO.Ports
Imports Microsoft.VisualBasic.Strings


<ComVisible(False)> _
Public Class SetupDialogForm

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click ' OK button event handler
        ' Persist new values of user settings to the ASCOM profile
        Dome.comPort = ComboBoxComPort.SelectedItem.ToString ' Update the state variables with results from the dialogue
        Dome.showStatusForm = chkShowStatus.Checked
        Dome.traceState = chkTrace.Checked
        Dome.canSpeak = chkSpeak.Checked
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click 'Cancel button event handler
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub ShowAscomWebPage(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.DoubleClick, PictureBox1.Click
        ' Click on ASCOM logo event handler
        Try
            System.Diagnostics.Process.Start("https://ascom-standards.org/")
        Catch noBrowser As System.ComponentModel.Win32Exception
            If noBrowser.ErrorCode = -2147467259 Then
                MessageBox.Show(noBrowser.Message)
            End If
        Catch other As System.Exception
            MessageBox.Show(other.Message)
        End Try
    End Sub

    Private Sub SetupDialogForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load ' Form load event handler
        ' Retrieve current values of user settings from the ASCOM Profile
        InitUI()
    End Sub

    Private Sub InitUI()
        lblCxn.Text = ""
        chkShowStatus.Checked = Dome.showStatusForm
        chkTrace.Checked = Dome.traceState
        chkSpeak.Checked = Dome.canSpeak
        lblDriverVersion.Text = Dome.version

        ' set the list of com ports to those that are currently available
        ComboBoxComPort.Items.Clear()
        ComboBoxComPort.Items.AddRange(System.IO.Ports.SerialPort.GetPortNames()) ' use System.IO because it's static
        Dim listLength As Integer = ComboBoxComPort.Items.Count - 1
        Dim list(listLength) As Integer
        For i = 0 To listLength
            list(i) = CInt(Mid(ComboBoxComPort.Items(i).ToString, 4, 3))
        Next
        Array.Sort(list)
        ComboBoxComPort.Items.Clear()
        For i = 0 To listLength
            ComboBoxComPort.Items.Add("COM" + list(i).ToString)
        Next
        ' select the current port if possible
        If ComboBoxComPort.Items.Contains(Dome.comPort) Then
            ComboBoxComPort.SelectedItem = Dome.comPort
        End If
    End Sub

    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        lblCxn.Text = ""
        lblVersion.Text = ""
        lblParked.Text = ""
        lblStatus.Text = ""
        lblBattery.Text = ""
        lblRain.Text = ""
        lblSafety.Text = ""
        Application.DoEvents()
        Dim resp As String
        Try
            resp = SerialCommand("V")
            If resp.StartsWith("RoofBuddy") Then
                lblCxn.Text = "RoofBuddy found"
                lblVersion.Text = Strings.Mid(resp, 11, 9)
            Else
                lblCxn.Text = "RoofBuddy NOT FOUND"
                Exit Sub
            End If
            SerialCommand("p")
            Select Case SerialCommand("L")
                Case "0"
                    lblParked.Text = "No"
                Case "1"
                    lblParked.Text = "Yes"
                Case "2"
                    lblParked.Text = "LX200 not responding"
                Case Else
                    lblParked.Text = "Unknown"
            End Select
            lblCxn.Text = "RoofBuddy found"
            Application.DoEvents()
            Select Case SerialCommand("s")
                Case "C"
                    lblStatus.Text = "Closed"
                Case "c"
                    lblStatus.Text = "Closing..."
                Case "O"
                    lblStatus.Text = "Open"
                Case "o"
                    lblStatus.Text = "Opening..."
                Case "h"
                    lblStatus.Text = "Partly open"
                Case "H"
                    lblStatus.Text = "Partly closed"
                Case "p"
                    lblStatus.Text = "Parking (open)"
                Case "P"
                    lblStatus.Text = "Parking (close)"
                Case "b"
                    lblStatus.Text = "No Power"
                Case "B"
                    lblStatus.Text = "No Power"
                Case "t"
                    lblStatus.Text = "Timed-out (op)"
                Case "T"
                    lblStatus.Text = "Timed-out (cl)"
                Case "r"
                    lblStatus.Text = "Raining (open)"
                Case "R"
                    lblStatus.Text = "Raining (close)"
                Case "s"
                    lblStatus.Text = "Not safe (open)"
                Case "S"
                    lblStatus.Text = "Not safe (close)"
                Case "l"
                    lblStatus.Text = "No cxn (open)"
                Case "L"
                    lblStatus.Text = "No cxn (close)"
                Case Else
                    lblStatus.Text = "Unknown"
            End Select

            resp = "0" + SerialCommand("b")
            resp = Val(resp).ToString
            If InStr(resp, ".") = 0 Then resp += ".0"
            lblBattery.Text = resp + "V" + IIf(Val(resp) < 6, " - no battery power", "").ToString
            resp = SerialCommand("r")
            lblRain.Text = IIf(resp = "0", "Dry", If(resp = "1", "Raining", "Unknown")).ToString
            lblSafety.Text = If(SerialCommand("S") = "0", "No", "Yes")
            Application.DoEvents()
        Catch ex As Exception
        End Try
    End Sub

    Private Function SerialCommand(cmdStr As String) As String
        Dim retStr As String = ""
        Dim objSerial As New SerialPort
        cmdStr = "^" + Asc(cmdStr).ToString + "$"

        Try
            With objSerial
                .PortName = Dome.comPort
                .BaudRate = 9600
                .ReadTimeout = 2000
                .WriteTimeout = 500
                .Open()
                .Write(cmdStr)
            End With
            retStr = objSerial.ReadTo("$")
        Catch ex As Exception
            lblCxn.Text = ""
        End Try

        objSerial.Close()
        objSerial.Dispose()
        Return retStr
    End Function

    Private Sub ComboBoxComPort_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxComPort.SelectedIndexChanged
        Dome.comPort = ComboBoxComPort.SelectedItem.ToString

        lblStatus.Text = ""
        lblVersion.Text = ""
        lblBattery.Text = ""
        lblRain.Text = ""
        lblCxn.Text = ""
        lblSafety.Text = ""
    End Sub

End Class
