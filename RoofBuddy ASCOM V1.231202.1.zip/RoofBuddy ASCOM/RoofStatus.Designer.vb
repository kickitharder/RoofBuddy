﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRoofStatus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.prgBar = New System.Windows.Forms.ProgressBar()
        Me.lblRoofStateHdg = New System.Windows.Forms.Label()
        Me.lbBatteryHdg = New System.Windows.Forms.Label()
        Me.btnAbort = New System.Windows.Forms.Button()
        Me.lblRoofState = New System.Windows.Forms.Label()
        Me.lblBattery = New System.Windows.Forms.Label()
        Me.lblTick = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'prgBar
        '
        Me.prgBar.Location = New System.Drawing.Point(20, 20)
        Me.prgBar.Name = "prgBar"
        Me.prgBar.Size = New System.Drawing.Size(200, 23)
        Me.prgBar.TabIndex = 0
        '
        'lblRoofStateHdg
        '
        Me.lblRoofStateHdg.AutoSize = True
        Me.lblRoofStateHdg.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRoofStateHdg.Location = New System.Drawing.Point(17, 56)
        Me.lblRoofStateHdg.Name = "lblRoofStateHdg"
        Me.lblRoofStateHdg.Size = New System.Drawing.Size(61, 13)
        Me.lblRoofStateHdg.TabIndex = 1
        Me.lblRoofStateHdg.Text = "Roof State:"
        '
        'lbBatteryHdg
        '
        Me.lbBatteryHdg.AutoSize = True
        Me.lbBatteryHdg.Location = New System.Drawing.Point(17, 80)
        Me.lbBatteryHdg.Name = "lbBatteryHdg"
        Me.lbBatteryHdg.Size = New System.Drawing.Size(43, 13)
        Me.lbBatteryHdg.TabIndex = 2
        Me.lbBatteryHdg.Text = "Battery:"
        '
        'btnAbort
        '
        Me.btnAbort.Location = New System.Drawing.Point(129, 104)
        Me.btnAbort.Name = "btnAbort"
        Me.btnAbort.Size = New System.Drawing.Size(91, 25)
        Me.btnAbort.TabIndex = 3
        Me.btnAbort.Text = "Abort"
        Me.btnAbort.UseVisualStyleBackColor = True
        '
        'lblRoofState
        '
        Me.lblRoofState.AutoSize = True
        Me.lblRoofState.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRoofState.Location = New System.Drawing.Point(84, 56)
        Me.lblRoofState.Name = "lblRoofState"
        Me.lblRoofState.Size = New System.Drawing.Size(10, 13)
        Me.lblRoofState.TabIndex = 4
        Me.lblRoofState.Text = "."
        '
        'lblBattery
        '
        Me.lblBattery.AutoSize = True
        Me.lblBattery.Location = New System.Drawing.Point(84, 80)
        Me.lblBattery.Name = "lblBattery"
        Me.lblBattery.Size = New System.Drawing.Size(10, 13)
        Me.lblBattery.TabIndex = 5
        Me.lblBattery.Text = "."
        '
        'lblTick
        '
        Me.lblTick.AutoSize = True
        Me.lblTick.Location = New System.Drawing.Point(17, 110)
        Me.lblTick.Name = "lblTick"
        Me.lblTick.Size = New System.Drawing.Size(10, 13)
        Me.lblTick.TabIndex = 6
        Me.lblTick.Text = "."
        '
        'frmRoofStatus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(240, 141)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblTick)
        Me.Controls.Add(Me.lblBattery)
        Me.Controls.Add(Me.lblRoofState)
        Me.Controls.Add(Me.btnAbort)
        Me.Controls.Add(Me.lbBatteryHdg)
        Me.Controls.Add(Me.lblRoofStateHdg)
        Me.Controls.Add(Me.prgBar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmRoofStatus"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "RoofBuddy"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents prgBar As ProgressBar
    Friend WithEvents lblRoofStateHdg As Label
    Friend WithEvents lbBatteryHdg As Label
    Friend WithEvents btnAbort As Button
    Friend WithEvents lblRoofState As Label
    Friend WithEvents lblBattery As Label
    Friend WithEvents lblTick As Label
End Class
