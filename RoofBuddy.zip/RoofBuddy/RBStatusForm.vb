﻿Imports System.IO.Ports

Public Class RBStatusForm
    Dim roofTimer As Integer = 0
    Dim sentence As String = ""
    Dim words As String = ""
    Dim finishingMove As Boolean

    Public Sub StartMove()
        Dim s = Dome.SerialCmd("b", True)
        If s = "No connection" Then s = Dome.SerialCmd("b", True)
        lblBattery.Text = s + "V"

        prgBar.Value = 1
        prgBar.Maximum = Dome.roofMovePeriod
        roofTimer = Dome.roofMovePeriod
        Select Case Dome.roofAction
            Case "o"
                Me.Text = "RoofBuddy - opening roof"
                lblRoofState.Text = "Opening roof"
            Case "c"
                Me.Text = "RoofBuddy - closing roof"
                lblRoofState.Text = "Closing roof"
                prgBar.Value = prgBar.Maximum
        End Select

        Me.Visible = True
        Application.DoEvents()
        Dome.roofMoveDone = False
        Dome.roofMoving = True
        Dome.SerialCmd(IIf(Dome.roofAction = "o", "O", "C"), False)    ' Start moving roof
        Speak(lblRoofState.Text)

        finishingMove = False
        Timer1.Interval = 2000
        Timer1.Enabled = True
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblTick.Text = IIf(lblTick.Text = "/", "\", "/")
        If finishingMove Then
            Me.Visible = False
            Timer1.Enabled = False
            Timer1.Stop()
        End If
        If Dome.roofStatus = DeviceInterface.ShutterState.shutterError Then
            If Not Dome.roofMoveDone Then Speak(Dome.roofStatusText)
            Dome.roofMoveDone = True
            Dome.roofMoving = False
            lblRoofState.Text = Dome.roofStatusText
            Dome.SerialCmd("H", False)
            Dome.SerialCmd("H", False)
            finishingMove = True
            Exit Sub
        End If

        Dome.GetRoofStatus()
        Application.DoEvents()
        If lblRoofState.Text <> Dome.roofStatusText Then
            lblRoofState.Text = Dome.roofStatusText
            Speak(Dome.roofStatusText)
        End If

        If Dome.roofMoveDone Then
            Dome.roofMoving = False
            finishingMove = True
            Speak(Dome.roofStatusText)
            Exit Sub
        End If

        If Dome.roofMoving Then
            roofTimer -= 2
            If roofTimer < 0 Then roofTimer = 0
            If Dome.roofAction = "o" Then prgBar.Value = prgBar.Maximum - roofTimer
            If Dome.roofAction = "c" Then prgBar.Value = roofTimer
        Else
            prgBar.Value = 0
            prgBar.Maximum = Dome.roofMovePeriod
            If Dome.roofAction = "o" Then prgBar.Value = prgBar.Maximum
            If Dome.roofAction = "c" Then prgBar.Value = 1
            roofTimer = Dome.roofMovePeriod
        End If

        Application.DoEvents()
    End Sub

    Private Sub btnAbort_Click(sender As Object, e As EventArgs) Handles btnAbort.Click
        Dome.roofStatusText = "Move aborted..."
        lblRoofState.Text = Dome.roofStatusText
        Dome.roofStatus = DeviceInterface.ShutterState.shutterError
        Dome.roofAction = "h"
        Dome.roofMoveDone = True
        Dome.roofMoving = False
        Application.DoEvents()
        Dome.SerialCmd("H", False)                  ' Stop the roof from moving
    End Sub

    Public Sub Speak(words As String)
        If Not Dome.canSpeak Then Exit Sub
        sentence = words
        Timer2.Interval = 1
        Timer2.Enabled = True
        Timer2.Start()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Timer2.Stop()
        If sentence = words Then Exit Sub
        words = sentence
        sentence = ""
        Dim SAPI As Object
        SAPI = CreateObject("SAPI.spvoice")
        SAPI.Voice = SAPI.GetVoices.Item(0)
        SAPI.rate = 0
        SAPI.speak(words)
    End Sub
End Class