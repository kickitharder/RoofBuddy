<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SetupDialogForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.chkTrace = New System.Windows.Forms.CheckBox()
        Me.ComboBoxComPort = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnCheck = New System.Windows.Forms.Button()
        Me.lblStatusText = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblBatteryText = New System.Windows.Forms.Label()
        Me.lblRainText = New System.Windows.Forms.Label()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.lblRain = New System.Windows.Forms.Label()
        Me.lblBattery = New System.Windows.Forms.Label()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.lblCxnText = New System.Windows.Forms.Label()
        Me.lblCxn = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblSafety = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblParked = New System.Windows.Forms.Label()
        Me.chkSpeak = New System.Windows.Forms.CheckBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OK_Button
        '
        Me.OK_Button.Location = New System.Drawing.Point(176, 252)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(176, 281)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Image = Global.ASCOM.RoofBuddy.My.Resources.Resources.ASCOM
        Me.PictureBox1.Location = New System.Drawing.Point(18, 232)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(48, 56)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(15, 45)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(52, 13)
        Me.label2.TabIndex = 7
        Me.label2.Text = "COM port"
        '
        'chkTrace
        '
        Me.chkTrace.AutoSize = True
        Me.chkTrace.Location = New System.Drawing.Point(80, 266)
        Me.chkTrace.Name = "chkTrace"
        Me.chkTrace.Size = New System.Drawing.Size(69, 17)
        Me.chkTrace.TabIndex = 8
        Me.chkTrace.Text = "Trace on"
        Me.chkTrace.UseVisualStyleBackColor = True
        '
        'ComboBoxComPort
        '
        Me.ComboBoxComPort.FormattingEnabled = True
        Me.ComboBoxComPort.Location = New System.Drawing.Point(73, 42)
        Me.ComboBoxComPort.Name = "ComboBoxComPort"
        Me.ComboBoxComPort.Size = New System.Drawing.Size(68, 21)
        Me.ComboBoxComPort.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Comic Sans MS", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(6, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(136, 34)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "RoofBuddy"
        '
        'btnCheck
        '
        Me.btnCheck.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheck.Location = New System.Drawing.Point(157, 42)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(73, 21)
        Me.btnCheck.TabIndex = 11
        Me.btnCheck.Text = "Check"
        Me.btnCheck.UseVisualStyleBackColor = True
        '
        'lblStatusText
        '
        Me.lblStatusText.AutoSize = True
        Me.lblStatusText.Location = New System.Drawing.Point(18, 145)
        Me.lblStatusText.Name = "lblStatusText"
        Me.lblStatusText.Size = New System.Drawing.Size(66, 13)
        Me.lblStatusText.TabIndex = 13
        Me.lblStatusText.Text = "Roof Status:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 294)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(118, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Diver Version 0.220501"
        '
        'lblBatteryText
        '
        Me.lblBatteryText.AutoSize = True
        Me.lblBatteryText.Location = New System.Drawing.Point(18, 167)
        Me.lblBatteryText.Name = "lblBatteryText"
        Me.lblBatteryText.Size = New System.Drawing.Size(43, 13)
        Me.lblBatteryText.TabIndex = 15
        Me.lblBatteryText.Text = "Battery:"
        '
        'lblRainText
        '
        Me.lblRainText.AutoSize = True
        Me.lblRainText.Location = New System.Drawing.Point(18, 189)
        Me.lblRainText.Name = "lblRainText"
        Me.lblRainText.Size = New System.Drawing.Size(68, 13)
        Me.lblRainText.TabIndex = 16
        Me.lblRainText.Text = "Rain Sensor:"
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = True
        Me.lblVersion.Location = New System.Drawing.Point(115, 101)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(10, 13)
        Me.lblVersion.TabIndex = 21
        Me.lblVersion.Text = "."
        '
        'lblRain
        '
        Me.lblRain.AutoSize = True
        Me.lblRain.Location = New System.Drawing.Point(113, 189)
        Me.lblRain.Name = "lblRain"
        Me.lblRain.Size = New System.Drawing.Size(10, 13)
        Me.lblRain.TabIndex = 20
        Me.lblRain.Text = "."
        '
        'lblBattery
        '
        Me.lblBattery.AutoSize = True
        Me.lblBattery.Location = New System.Drawing.Point(115, 167)
        Me.lblBattery.Name = "lblBattery"
        Me.lblBattery.Size = New System.Drawing.Size(10, 13)
        Me.lblBattery.TabIndex = 19
        Me.lblBattery.Text = "."
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New System.Drawing.Point(115, 145)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(10, 13)
        Me.lblStatus.TabIndex = 18
        Me.lblStatus.Text = "."
        '
        'lblCxnText
        '
        Me.lblCxnText.AutoSize = True
        Me.lblCxnText.Location = New System.Drawing.Point(18, 79)
        Me.lblCxnText.Name = "lblCxnText"
        Me.lblCxnText.Size = New System.Drawing.Size(64, 13)
        Me.lblCxnText.TabIndex = 22
        Me.lblCxnText.Text = "Connection:"
        '
        'lblCxn
        '
        Me.lblCxn.AutoSize = True
        Me.lblCxn.Location = New System.Drawing.Point(115, 79)
        Me.lblCxn.Name = "lblCxn"
        Me.lblCxn.Size = New System.Drawing.Size(10, 13)
        Me.lblCxn.TabIndex = 23
        Me.lblCxn.Text = "."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 101)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 13)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "Version:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(18, 211)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(94, 13)
        Me.Label6.TabIndex = 27
        Me.Label6.Text = "Safe to move roof:"
        '
        'lblSafety
        '
        Me.lblSafety.AutoSize = True
        Me.lblSafety.Location = New System.Drawing.Point(115, 211)
        Me.lblSafety.Name = "lblSafety"
        Me.lblSafety.Size = New System.Drawing.Size(10, 13)
        Me.lblSafety.TabIndex = 28
        Me.lblSafety.Text = "."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(17, 123)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(47, 13)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Parked?"
        '
        'lblParked
        '
        Me.lblParked.AutoSize = True
        Me.lblParked.Location = New System.Drawing.Point(114, 123)
        Me.lblParked.Name = "lblParked"
        Me.lblParked.Size = New System.Drawing.Size(10, 13)
        Me.lblParked.TabIndex = 29
        Me.lblParked.Text = "."
        '
        'chkSpeak
        '
        Me.chkSpeak.AutoSize = True
        Me.chkSpeak.Checked = True
        Me.chkSpeak.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkSpeak.Location = New System.Drawing.Point(80, 239)
        Me.chkSpeak.Name = "chkSpeak"
        Me.chkSpeak.Size = New System.Drawing.Size(57, 17)
        Me.chkSpeak.TabIndex = 31
        Me.chkSpeak.Text = "Speak"
        Me.chkSpeak.UseVisualStyleBackColor = True
        '
        'SetupDialogForm
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(255, 313)
        Me.Controls.Add(Me.chkSpeak)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblParked)
        Me.Controls.Add(Me.lblSafety)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Cancel_Button)
        Me.Controls.Add(Me.OK_Button)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblCxn)
        Me.Controls.Add(Me.lblCxnText)
        Me.Controls.Add(Me.lblVersion)
        Me.Controls.Add(Me.lblRain)
        Me.Controls.Add(Me.lblBattery)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.lblRainText)
        Me.Controls.Add(Me.lblBatteryText)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblStatusText)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ComboBoxComPort)
        Me.Controls.Add(Me.chkTrace)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SetupDialogForm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "RoofBuddy Setup"
        Me.TopMost = True
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents chkTrace As System.Windows.Forms.CheckBox
    Friend WithEvents ComboBoxComPort As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btnCheck As Button
    Friend WithEvents lblStatusText As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblBatteryText As Label
    Friend WithEvents lblRainText As Label
    Friend WithEvents lblVersion As Label
    Friend WithEvents lblRain As Label
    Friend WithEvents lblBattery As Label
    Friend WithEvents lblStatus As Label
    Friend WithEvents lblCxnText As Label
    Friend WithEvents lblCxn As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblSafety As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblParked As Label
    Friend WithEvents chkSpeak As CheckBox
End Class
