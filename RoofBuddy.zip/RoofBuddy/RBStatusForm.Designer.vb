﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class RBStatusForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.prgBar = New System.Windows.Forms.ProgressBar()
        Me.btnAbort = New System.Windows.Forms.Button()
        Me.lblRoofState = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblBattery = New System.Windows.Forms.Label()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.lblTick = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'prgBar
        '
        Me.prgBar.Location = New System.Drawing.Point(12, 12)
        Me.prgBar.Name = "prgBar"
        Me.prgBar.Size = New System.Drawing.Size(180, 23)
        Me.prgBar.Step = 1
        Me.prgBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.prgBar.TabIndex = 0
        '
        'btnAbort
        '
        Me.btnAbort.Location = New System.Drawing.Point(117, 88)
        Me.btnAbort.Name = "btnAbort"
        Me.btnAbort.Size = New System.Drawing.Size(75, 23)
        Me.btnAbort.TabIndex = 1
        Me.btnAbort.Text = "Abort"
        Me.btnAbort.UseVisualStyleBackColor = True
        '
        'lblRoofState
        '
        Me.lblRoofState.AutoSize = True
        Me.lblRoofState.Location = New System.Drawing.Point(72, 48)
        Me.lblRoofState.Name = "lblRoofState"
        Me.lblRoofState.Size = New System.Drawing.Size(73, 13)
        Me.lblRoofState.TabIndex = 2
        Me.lblRoofState.Text = "Opening Roof"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Roof State:"
        '
        'Timer1
        '
        Me.Timer1.Interval = 2000
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 70)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Battery:"
        '
        'lblBattery
        '
        Me.lblBattery.AutoSize = True
        Me.lblBattery.Location = New System.Drawing.Point(72, 70)
        Me.lblBattery.Name = "lblBattery"
        Me.lblBattery.Size = New System.Drawing.Size(35, 13)
        Me.lblBattery.TabIndex = 7
        Me.lblBattery.Text = "12.0V"
        '
        'Timer2
        '
        Me.Timer2.Interval = 1
        '
        'lblTick
        '
        Me.lblTick.AutoSize = True
        Me.lblTick.Location = New System.Drawing.Point(12, 101)
        Me.lblTick.Name = "lblTick"
        Me.lblTick.Size = New System.Drawing.Size(12, 13)
        Me.lblTick.TabIndex = 8
        Me.lblTick.Text = "\"
        '
        'RBStatusForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(206, 121)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblTick)
        Me.Controls.Add(Me.lblBattery)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblRoofState)
        Me.Controls.Add(Me.btnAbort)
        Me.Controls.Add(Me.prgBar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "RBStatusForm"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "RoofBuddy"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents prgBar As ProgressBar
    Friend WithEvents btnAbort As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label3 As Label
    Friend WithEvents lblBattery As Label
    Friend WithEvents lblRoofState As Label
    Friend WithEvents Timer2 As Timer
    Friend WithEvents lblTick As Label
End Class
